package fr.fusiontotk;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class FusionRules {
    private FusionRules() {}

    /** Retourne l'identifiant de fusion, ou null si la combinaison est impossible. */
    public static String find(ItemStack tool, ItemStack ingredient) {
        if (tool.isEmpty() || ingredient.isEmpty()) return null;
        if (tool.is(ItemTags.PICKAXES) && ingredient.is(Items.TNT)) return "pickaxe_tnt";
        if (tool.is(ItemTags.SHOVELS) && isSnowOrIce(ingredient)) return "shovel_snow";
        if (tool.is(ItemTags.AXES) && ingredient.is(ItemTags.LEAVES)) return "axe_leaves";
        if (tool.is(Items.FISHING_ROD) && ingredient.is(Items.SLIME_BLOCK)) return "rod_slime";
        if (tool.is(Items.FLINT_AND_STEEL) && isIce(ingredient)) return "flint_ice";
        if (tool.is(Items.SHIELD) && ingredient.is(Items.SLIME_BLOCK)) return "shield_slime";
        if (isTool(tool) && isConcrete(ingredient)) return "tool_concrete";
        if (isTool(tool) && isDryPlant(ingredient)) return "tool_dry_plant";
        return null;
    }

    /** Source unique de vérité pour "cet objet peut recevoir une fusion" (serveur ET client). */
    public static boolean isTool(ItemStack s) {
        return s.is(ItemTags.PICKAXES) || s.is(ItemTags.SHOVELS) || s.is(ItemTags.AXES)
            || s.is(ItemTags.HOES) || s.is(ItemTags.SWORDS)
            || s.is(Items.SHEARS) || s.is(Items.FISHING_ROD)
            || s.is(Items.SHIELD) || s.is(Items.FLINT_AND_STEEL);
    }

    public static String displayName(String id) {
        return switch (id) {
            case "pickaxe_tnt" -> "Pioche + TNT";
            case "shovel_snow" -> "Pelle + neige/glace";
            case "axe_leaves" -> "Hache + feuilles";
            case "rod_slime" -> "Canne + slime";
            case "flint_ice" -> "Briquet + glace";
            case "shield_slime" -> "Bouclier + slime";
            case "tool_concrete" -> "Outil + béton";
            case "tool_dry_plant" -> "Outil + végétation sèche";
            default -> id;
        };
    }

    private static boolean isSnowOrIce(ItemStack s) {
        return isIce(s) || s.is(Items.SNOW_BLOCK) || s.is(Items.SNOWBALL) || s.is(Items.POWDER_SNOW_BUCKET);
    }

    // Note : Items.FROSTED_ICE n'existe pas (c'est un bloc sans item) -> retiré.
    private static boolean isIce(ItemStack s) {
        return s.is(Items.ICE) || s.is(Items.PACKED_ICE) || s.is(Items.BLUE_ICE);
    }

    private static boolean isConcrete(ItemStack s) {
        String path = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
        return path.endsWith("_concrete") || path.endsWith("_concrete_powder");
    }

    // Fougère retirée : ce n'est pas de la végétation "sèche".
    private static boolean isDryPlant(ItemStack s) {
        return s.is(Items.DEAD_BUSH) || s.is(Items.SHORT_DRY_GRASS) || s.is(Items.TALL_DRY_GRASS);
    }
}
