package fr.fusiontotk;

import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.Optional;

/** Logique de visée partagée : le client met en surbrillance exactement ce que le serveur fusionnera. */
public final class FusionTargeting {
    public static final double RANGE = 5.0;
    private static final double MIN_DOT = 0.94; // ~20° de demi-angle

    private FusionTargeting() {}

    public static Optional<ItemEntity> find(Player player, ItemStack tool) {
        if (!FusionRules.isTool(tool)) return Optional.empty();

        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        AABB box = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.5);

        return player.level().getEntitiesOfClass(ItemEntity.class, box, e ->
                        e.isAlive()
                        && !e.getItem().isEmpty()
                        && FusionRules.find(tool, e.getItem()) != null
                        && inViewCone(eye, look, e.getBoundingBox().getCenter()))
                .stream()
                .min(Comparator.comparingDouble(e -> e.getBoundingBox().getCenter().distanceToSqr(eye)));
    }

    private static boolean inViewCone(Vec3 eye, Vec3 look, Vec3 target) {
        Vec3 delta = target.subtract(eye);
        double distance = delta.length();
        if (distance > RANGE || distance < 0.01) return false;
        return look.dot(delta.scale(1.0 / distance)) > MIN_DOT;
    }
}
