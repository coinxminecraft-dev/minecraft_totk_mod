package fr.fusiontotk;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

public class FusionTotKClient implements ClientModInitializer {
    private static KeyMapping fuseKey;
    private static ItemEntity glowing;

    @Override
    public void onInitializeClient() {
        fuseKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.fusiontotk.fuse",
                GLFW.GLFW_KEY_R,
                KeyMapping.Category.GAMEPLAY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (fuseKey.consumeClick()) {
                if (client.player != null && client.level != null) {
                    ClientPlayNetworking.send(FusionTotK.FuseRequest.INSTANCE);
                }
            }
            updateTargetGlow(client);
        });
    }

    private static void updateTargetGlow(Minecraft client) {
        ItemEntity next = null;
        if (client.level != null && client.player != null) {
            ItemStack held = client.player.getMainHandItem();
            if (!FusionData.hasFusion(held)) {
                next = FusionTargeting.find(client.player, held).orElse(null);
            }
        }
        if (next == glowing) return;

        // Ne touche qu'à l'entité précédemment éclairée (pas de reset de tous les objets proches).
        if (glowing != null && !glowing.isRemoved()) glowing.setGlowingTag(false);
        if (next != null) next.setGlowingTag(true);
        glowing = next;
    }
}
