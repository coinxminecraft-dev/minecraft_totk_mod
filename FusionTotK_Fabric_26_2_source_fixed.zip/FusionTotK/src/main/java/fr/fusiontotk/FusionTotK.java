package fr.fusiontotk;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;

public class FusionTotK implements ModInitializer {
    public static final String MOD_ID = "fusiontotk";

    public static final CustomPacketPayload.Type<FuseRequest> FUSE_REQUEST =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(MOD_ID, "fuse_request"));

    public record FuseRequest() implements CustomPacketPayload {
        public static final FuseRequest INSTANCE = new FuseRequest();
        public static final StreamCodec<RegistryFriendlyByteBuf, FuseRequest> CODEC =
                StreamCodec.unit(INSTANCE);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return FUSE_REQUEST;
        }
    }

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(FUSE_REQUEST, FuseRequest.CODEC);
        // Le handler Fabric s'exécute déjà sur le thread serveur : pas besoin de server.execute().
        ServerPlayNetworking.registerGlobalReceiver(FUSE_REQUEST,
                (payload, context) -> tryFuse(context.player()));
    }

    private static void tryFuse(ServerPlayer player) {
        ItemStack held = player.getMainHandItem();
        if (!FusionRules.isTool(held)) return;

        if (FusionData.hasFusion(held)) {
            player.displayClientMessage(
                    Component.literal("Cet objet est déjà fusionné").withStyle(ChatFormatting.RED), true);
            return;
        }

        var target = FusionTargeting.find(player, held);
        if (target.isEmpty()) {
            player.displayClientMessage(
                    Component.literal("Aucun objet compatible visé").withStyle(ChatFormatting.GRAY), true);
            return;
        }

        ItemEntity entity = target.get();
        ItemStack stack = entity.getItem();
        String fusion = FusionRules.find(held, stack);
        if (fusion == null) return;

        // Consomme exactement un objet, sur une copie, puis réécrit la pile de l'entité.
        ItemStack one = stack.copyWithCount(1);
        ItemStack remaining = stack.copy();
        remaining.shrink(1);
        if (remaining.isEmpty()) entity.discard();
        else entity.setItem(remaining);

        FusionData.setFusion(held, fusion, one);
        player.displayClientMessage(
                Component.literal("Fusion : ").withStyle(ChatFormatting.GREEN)
                        .append(Component.literal(FusionRules.displayName(fusion)).withStyle(ChatFormatting.WHITE)),
                true);
    }
}
