package fr.fusiontotk;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

public final class FusionData {
    private static final String KEY_ID = "fusiontotk_id";
    private static final String KEY_ITEM = "fusiontotk_item";

    private FusionData() {}

    public static void setFusion(ItemStack tool, String fusionId, ItemStack ingredient) {
        CompoundTag tag = tool.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        tag.putString(KEY_ID, fusionId);
        // Identifiant de registre ("minecraft:tnt") plutôt que Item#toString(), non garanti stable.
        tag.putString(KEY_ITEM, BuiltInRegistries.ITEM.getKey(ingredient.getItem()).toString());
        tool.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    public static String getFusion(ItemStack tool) {
        CompoundTag tag = tool.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return tag.getString(KEY_ID).orElse("");
    }

    public static boolean hasFusion(ItemStack tool) {
        return !getFusion(tool).isEmpty();
    }
}
