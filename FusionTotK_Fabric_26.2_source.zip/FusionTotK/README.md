# Fusion TotK — prototype Fabric 26.2

Prototype de départ pour un mod de fusion inspiré de TotK.

## Cible
- Minecraft Java 26.2
- Fabric Loader 0.19.3
- Fabric API 0.161.0+26.2
- Java 25
- Loom 1.17 / Gradle 9.5.1

## État actuel
Cette archive contient les sources d'un prototype, pas un `.jar` certifié. Les APIs de Minecraft 26.2 ont changé et le projet doit être compilé puis corrigé avec l'environnement 26.2 exact avant de le considérer prêt à jouer.

Fonctions prévues dans ce prototype :
- touche R enregistrée côté client ;
- demande de fusion envoyée au serveur ;
- recherche d'un objet au sol dans le cône de visée ;
- consommation d'un seul objet et mémorisation de l'identifiant de fusion dans les données de l'outil ;
- règles initiales pour TNT, neige/glace, feuilles, slime, béton et végétation sèche ;
- repérage visuel des cibles compatibles par lueur vanilla (actuellement pas encore teintée en vert).

## Construire
1. Installe un JDK 25.
2. Ouvre le dossier dans IntelliJ IDEA ou un terminal avec Gradle installé.
3. Exécute `gradle build`.
4. Si la compilation échoue, vérifier les noms de classes/API 26.2 dans les erreurs Gradle et ajuster les sources.
5. Le JAR produit, après compilation réussie, sera dans `build/libs/`.

## Limites importantes
Les effets actifs (minage 3x3, création de neige, pièges de feuilles, grappin, vapeur) et le rendu de contour vert personnalisé restent à implémenter. Cette première archive établit la structure de données et le protocole de fusion ; ne la traite pas comme une version finale jouable.
