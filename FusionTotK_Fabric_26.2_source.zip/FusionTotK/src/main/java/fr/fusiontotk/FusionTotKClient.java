package fr.fusiontotk;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public class FusionTotKClient implements ClientModInitializer {
    private static KeyMapping fuseKey;

    @Override
    public void onInitializeClient() {
        fuseKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.fusiontotk.fuse",
                GLFW.GLFW_KEY_R,
                KeyMapping.Category.GAMEPLAY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (fuseKey.consumeClick()) {
                if (client.player != null && client.level != null) {
                    ClientPlayNetworking.send(new FusionTotK.FuseRequest());
                }
            }
            updateTargetGlow(client);
        });
    }

    private static void updateTargetGlow(Minecraft client) {
        if (client.level == null || client.player == null) return;
        // Reset only nearby dropped items; no world-wide scan.
        var player = client.player;
        var eye = player.getEyePosition();
        var look = player.getLookAngle();
        var box = player.getBoundingBox().inflate(6.0);
        for (ItemEntity item : client.level.getEntitiesOfClass(ItemEntity.class, box)) {
            boolean valid = isPotentialTool(player.getMainHandItem())
                    && isPotentialIngredient(player.getMainHandItem(), item.getItem())
                    && eye.distanceTo(item.position()) <= 5.0
                    && look.dot(item.position().subtract(eye).normalize()) > 0.94;
            // Vanilla glowing outline is a fallback until the custom green outline renderer is added.
            item.setGlowingTag(valid);
        }
    }

    private static boolean isPotentialTool(ItemStack s) {
        return s.is(Items.WOODEN_PICKAXE) || s.is(Items.STONE_PICKAXE) || s.is(Items.IRON_PICKAXE)
            || s.is(Items.GOLDEN_PICKAXE) || s.is(Items.DIAMOND_PICKAXE) || s.is(Items.NETHERITE_PICKAXE)
            || s.is(Items.WOODEN_SHOVEL) || s.is(Items.STONE_SHOVEL) || s.is(Items.IRON_SHOVEL)
            || s.is(Items.GOLDEN_SHOVEL) || s.is(Items.DIAMOND_SHOVEL) || s.is(Items.NETHERITE_SHOVEL)
            || s.is(Items.WOODEN_AXE) || s.is(Items.STONE_AXE) || s.is(Items.IRON_AXE)
            || s.is(Items.GOLDEN_AXE) || s.is(Items.DIAMOND_AXE) || s.is(Items.NETHERITE_AXE)
            || s.is(Items.SHIELD) || s.is(Items.FISHING_ROD) || s.is(Items.FLINT_AND_STEEL)
            || s.is(Items.SHEARS);
    }

    private static boolean isPotentialIngredient(ItemStack tool, ItemStack ingredient) {
        return FusionRules.find(tool, ingredient) != null;
    }
}
