package fr.fusiontotk;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.Set;

public final class FusionRules {
    private FusionRules() {}

    public static String find(ItemStack tool, ItemStack ingredient) {
        // Rules intentionally use vanilla item identity, not display names.
        if (isPickaxe(tool) && ingredient.is(Items.TNT)) return "pickaxe_tnt";
        if (isShovel(tool) && isSnowOrIce(ingredient)) return "shovel_snow";
        if (isAxe(tool) && isLeafItem(ingredient)) return "axe_leaves";
        if (tool.is(Items.FISHING_ROD) && ingredient.is(Items.SLIME_BLOCK)) return "rod_slime";
        if (tool.is(Items.FLINT_AND_STEEL) && isIce(ingredient)) return "flint_ice";
        if (tool.is(Items.SHIELD) && ingredient.is(Items.SLIME_BLOCK)) return "shield_slime";
        if (isAnyTool(tool) && isConcrete(ingredient)) return "tool_concrete";
        if (isAnyTool(tool) && isDeadBushFamily(ingredient)) return "tool_dry_plant";
        return null;
    }

    public static String displayName(String id) {
        return switch (id) {
            case "pickaxe_tnt" -> "Pioche + TNT";
            case "shovel_snow" -> "Pelle + neige/glace";
            case "axe_leaves" -> "Hache + feuilles";
            case "rod_slime" -> "Canne + slime";
            case "flint_ice" -> "Briquet + glace";
            case "shield_slime" -> "Bouclier + slime";
            case "tool_concrete" -> "Outil + béton";
            case "tool_dry_plant" -> "Outil + végétation sèche";
            default -> id;
        };
    }

    private static boolean isPickaxe(ItemStack s) {
        return s.is(Items.WOODEN_PICKAXE) || s.is(Items.STONE_PICKAXE) || s.is(Items.IRON_PICKAXE)
            || s.is(Items.GOLDEN_PICKAXE) || s.is(Items.DIAMOND_PICKAXE) || s.is(Items.NETHERITE_PICKAXE);
    }
    private static boolean isShovel(ItemStack s) {
        return s.is(Items.WOODEN_SHOVEL) || s.is(Items.STONE_SHOVEL) || s.is(Items.IRON_SHOVEL)
            || s.is(Items.GOLDEN_SHOVEL) || s.is(Items.DIAMOND_SHOVEL) || s.is(Items.NETHERITE_SHOVEL);
    }
    private static boolean isAxe(ItemStack s) {
        return s.is(Items.WOODEN_AXE) || s.is(Items.STONE_AXE) || s.is(Items.IRON_AXE)
            || s.is(Items.GOLDEN_AXE) || s.is(Items.DIAMOND_AXE) || s.is(Items.NETHERITE_AXE);
    }
    private static boolean isAnyTool(ItemStack s) {
        return isPickaxe(s) || isShovel(s) || isAxe(s) || s.is(Items.SHEARS) || s.is(Items.FISHING_ROD)
            || s.is(Items.WOODEN_HOE) || s.is(Items.STONE_HOE) || s.is(Items.IRON_HOE)
            || s.is(Items.GOLDEN_HOE) || s.is(Items.DIAMOND_HOE) || s.is(Items.NETHERITE_HOE)
            || s.is(Items.WOODEN_SWORD) || s.is(Items.STONE_SWORD) || s.is(Items.IRON_SWORD)
            || s.is(Items.GOLDEN_SWORD) || s.is(Items.DIAMOND_SWORD) || s.is(Items.NETHERITE_SWORD)
            || s.is(Items.SHIELD) || s.is(Items.FLINT_AND_STEEL);
    }
    private static boolean isSnowOrIce(ItemStack s) {
        return isIce(s) || s.is(Items.SNOW_BLOCK) || s.is(Items.SNOWBALL) || s.is(Items.POWDER_SNOW_BUCKET);
    }
    private static boolean isIce(ItemStack s) {
        return s.is(Items.ICE) || s.is(Items.PACKED_ICE) || s.is(Items.BLUE_ICE) || s.is(Items.FROSTED_ICE);
    }
    private static boolean isLeafItem(ItemStack s) {
        return s.is(Items.OAK_LEAVES) || s.is(Items.SPRUCE_LEAVES) || s.is(Items.BIRCH_LEAVES)
            || s.is(Items.JUNGLE_LEAVES) || s.is(Items.ACACIA_LEAVES) || s.is(Items.DARK_OAK_LEAVES)
            || s.is(Items.MANGROVE_LEAVES) || s.is(Items.CHERRY_LEAVES) || s.is(Items.AZALEA_LEAVES)
            || s.is(Items.FLOWERING_AZALEA_LEAVES);
    }
    private static boolean isConcrete(ItemStack s) {
        return s.is(Items.WHITE_CONCRETE) || s.is(Items.ORANGE_CONCRETE) || s.is(Items.MAGENTA_CONCRETE)
            || s.is(Items.LIGHT_BLUE_CONCRETE) || s.is(Items.YELLOW_CONCRETE) || s.is(Items.LIME_CONCRETE)
            || s.is(Items.PINK_CONCRETE) || s.is(Items.GRAY_CONCRETE) || s.is(Items.LIGHT_GRAY_CONCRETE)
            || s.is(Items.CYAN_CONCRETE) || s.is(Items.PURPLE_CONCRETE) || s.is(Items.BLUE_CONCRETE)
            || s.is(Items.BROWN_CONCRETE) || s.is(Items.GREEN_CONCRETE) || s.is(Items.RED_CONCRETE)
            || s.is(Items.BLACK_CONCRETE) || s.is(Items.WHITE_CONCRETE_POWDER)
            || s.is(Items.ORANGE_CONCRETE_POWDER) || s.is(Items.MAGENTA_CONCRETE_POWDER)
            || s.is(Items.LIGHT_BLUE_CONCRETE_POWDER) || s.is(Items.YELLOW_CONCRETE_POWDER)
            || s.is(Items.LIME_CONCRETE_POWDER) || s.is(Items.PINK_CONCRETE_POWDER)
            || s.is(Items.GRAY_CONCRETE_POWDER) || s.is(Items.LIGHT_GRAY_CONCRETE_POWDER)
            || s.is(Items.CYAN_CONCRETE_POWDER) || s.is(Items.PURPLE_CONCRETE_POWDER)
            || s.is(Items.BLUE_CONCRETE_POWDER) || s.is(Items.BROWN_CONCRETE_POWDER)
            || s.is(Items.GREEN_CONCRETE_POWDER) || s.is(Items.RED_CONCRETE_POWDER)
            || s.is(Items.BLACK_CONCRETE_POWDER);
    }
    private static boolean isDeadBushFamily(ItemStack s) {
        return s.is(Items.DEAD_BUSH) || s.is(Items.SHORT_DRY_GRASS) || s.is(Items.TALL_DRY_GRASS) || s.is(Items.FERN);
    }
}
