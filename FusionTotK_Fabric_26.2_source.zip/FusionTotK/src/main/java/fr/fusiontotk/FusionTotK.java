package fr.fusiontotk;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.Optional;

public class FusionTotK implements ModInitializer {
    public static final String MOD_ID = "fusiontotk";
    public static final CustomPayload.Type<FuseRequest> FUSE_REQUEST =
            new CustomPayload.Type<>(ResourceLocation.fromNamespaceAndPath(MOD_ID, "fuse_request"));

    public record FuseRequest() implements CustomPayload {
        public static final PacketCodec<RegistryByteBuf, FuseRequest> CODEC =
                PacketCodec.unit(new FuseRequest());
        @Override public Type<? extends CustomPayload> type() { return FUSE_REQUEST; }
    }

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(FUSE_REQUEST, FuseRequest.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(FUSE_REQUEST, (payload, context) ->
                context.server().execute(() -> tryFuse(context.player())));
    }

    private static void tryFuse(ServerPlayer player) {
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty() || !isTool(held)) return;

        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(5.0));
        AABB searchBox = player.getBoundingBox().expandTowards(look.scale(5.0)).inflate(1.0);
        Optional<ItemEntity> target = player.level().getEntitiesOfClass(
                ItemEntity.class, searchBox,
                entity -> entity.isAlive() && entity.getItem() != null && !entity.getItem().isEmpty()
        ).stream()
          .filter(entity -> isInViewCone(eye, look, entity.position(), 5.0))
          .min(Comparator.comparingDouble(entity -> eye.distanceToSqr(entity.position())));

        if (target.isEmpty()) return;
        ItemEntity entity = target.get();
        ItemStack ingredient = entity.getItem();
        String fusion = FusionRules.find(held, ingredient);
        if (fusion == null) return;

        // Consume exactly one ingredient; store the fusion on the held stack.
        ItemStack one = ingredient.copyWithCount(1);
        ingredient.shrink(1);
        if (ingredient.isEmpty()) entity.discard();
        else entity.setItem(ingredient);

        FusionData.setFusion(held, fusion, one);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                "§aFusion : §f" + FusionRules.displayName(fusion)), true);
    }

    private static boolean isInViewCone(Vec3 eye, Vec3 look, Vec3 target, double range) {
        Vec3 delta = target.subtract(eye);
        double distance = delta.length();
        if (distance > range || distance < 0.01) return false;
        return look.dot(delta.normalize()) > 0.94;
    }

    private static boolean isTool(ItemStack stack) {
        return stack.is(Items.WOODEN_PICKAXE) || stack.is(Items.STONE_PICKAXE)
            || stack.is(Items.IRON_PICKAXE) || stack.is(Items.GOLDEN_PICKAXE)
            || stack.is(Items.DIAMOND_PICKAXE) || stack.is(Items.NETHERITE_PICKAXE)
            || stack.is(Items.WOODEN_SHOVEL) || stack.is(Items.STONE_SHOVEL)
            || stack.is(Items.IRON_SHOVEL) || stack.is(Items.GOLDEN_SHOVEL)
            || stack.is(Items.DIAMOND_SHOVEL) || stack.is(Items.NETHERITE_SHOVEL)
            || stack.is(Items.WOODEN_AXE) || stack.is(Items.STONE_AXE)
            || stack.is(Items.IRON_AXE) || stack.is(Items.GOLDEN_AXE)
            || stack.is(Items.DIAMOND_AXE) || stack.is(Items.NETHERITE_AXE)
            || stack.is(Items.WOODEN_HOE) || stack.is(Items.STONE_HOE)
            || stack.is(Items.IRON_HOE) || stack.is(Items.GOLDEN_HOE)
            || stack.is(Items.DIAMOND_HOE) || stack.is(Items.NETHERITE_HOE)
            || stack.is(Items.WOODEN_SWORD) || stack.is(Items.STONE_SWORD)
            || stack.is(Items.IRON_SWORD) || stack.is(Items.GOLDEN_SWORD)
            || stack.is(Items.DIAMOND_SWORD) || stack.is(Items.NETHERITE_SWORD)
            || stack.is(Items.SHIELD) || stack.is(Items.FISHING_ROD)
            || stack.is(Items.SHEARS) || stack.is(Items.FLINT_AND_STEEL);
    }
}
