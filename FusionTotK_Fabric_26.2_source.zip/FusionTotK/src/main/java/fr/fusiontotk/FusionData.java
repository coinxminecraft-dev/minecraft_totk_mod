package fr.fusiontotk;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

public final class FusionData {
    private FusionData() {}

    public static void setFusion(ItemStack tool, String fusionId, ItemStack ingredient) {
        CompoundTag tag = tool.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        tag.putString("fusiontotk_id", fusionId);
        tag.putString("fusiontotk_item", ingredient.getItem().toString());
        tool.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    public static String getFusion(ItemStack tool) {
        CompoundTag tag = tool.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return tag.getString("fusiontotk_id").orElse("");
    }
}
